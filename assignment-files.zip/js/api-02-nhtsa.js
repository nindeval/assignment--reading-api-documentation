/*
##### National Highway Transit Safety Administration
https://vpic.nhtsa.dot.gov/api/

1. How many types of Chevrolet models are registered with the NHTSA?

2. What are the vehicle types that Nissan has?

3. What are the types of models that exist for Toyota trucks in 2017?

*/
